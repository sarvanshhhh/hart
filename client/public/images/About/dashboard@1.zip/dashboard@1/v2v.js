// Function to update speed, distance, and alerts in real-time
function updateVehicleData() {
    let speed1 = Math.floor(Math.random() * 20) + 50; // Random speed between 50-70 km/h
    let speed2 = Math.floor(Math.random() * 20) + 50;

    let distance1 = Math.floor(Math.random() * 10) + 10; // Random distance between 10-20 meters
    let distance2 = Math.floor(Math.random() * 10) + 10;

    document.getElementById("speed1").textContent = speed1;
    document.getElementById("speed2").textContent = speed2;
    document.getElementById("distance1").textContent = distance1;
    document.getElementById("distance2").textContent = distance2;

    let alertBox = document.getElementById("alertBox");

    // Speed difference alert
    if (Math.abs(speed1 - speed2) > 10) {
        alertBox.style.display = "block";
        alertBox.innerHTML = "⚠️ Speed Difference Too High! Adjust Speed.";
    } 
    // Distance alert
    else if (distance1 < 5 || distance2 < 5) {
        alertBox.style.display = "block";
        alertBox.innerHTML = "🚨 Vehicles too close! Maintain Distance.";
    } 
    else {
        alertBox.style.display = "none";
    }
}

// Function to check lane safety
function checkLaneSafety() {
    let laneChangeRisk = Math.random() > 0.5;
    let alertBox = document.getElementById("alertBox");

    if (laneChangeRisk) {
        alertBox.style.display = "block";
        alertBox.innerHTML = "⚠️ Unsafe Lane Change Detected!";
    } else {
        alertBox.style.display = "block";
        alertBox.innerHTML = "✅ Lane Change Safe!";
    }

    setTimeout(() => {
        alertBox.style.display = "none";
    }, 3000);
}

// Function for emergency braking
function emergencyBraking() {
    let alertBox = document.getElementById("alertBox");
    alertBox.style.display = "block";
    alertBox.innerHTML = "🛑 Emergency Braking Activated!";
    
    setTimeout(() => {
        alertBox.style.display = "none";
    }, 3000);
}

// Dynamic traffic signal changes every 5 seconds
setInterval(() => {
    let lights = ["🟢 Green", "🟡 Yellow", "🔴 Red"];
    document.getElementById("traffic-light").textContent = lights[Math.floor(Math.random() * lights.length)];
}, 5000);

// Continuously update speed and distance every second
setInterval(updateVehicleData, 1000);
