document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const rangeValue = document.getElementById('range-value');
    const batteryPercent = document.getElementById('battery-percent');
    const efficiency = document.getElementById('efficiency');
    const circleProgress = document.getElementById('circle-progress');
    const speed = document.getElementById('speed');
    const power = document.getElementById('power');
    const temp = document.getElementById('temp');
    const speedGauge = document.getElementById('speed-gauge');
    const powerGauge = document.getElementById('power-gauge');
    const tempGauge = document.getElementById('temp-gauge');
    const navItems = document.querySelectorAll('.nav-item');
    
    // Initial values
    let currentRange = 387;
    let currentBattery = 92;
    let currentEfficiency = 4.2;
    let currentSpeed = 87;
    let currentPower = 142;
    let currentTemp = 64;
    
    // Update all displays
    function updateDisplays() {
        // Range display
        rangeValue.textContent = Math.round(currentRange);
        batteryPercent.textContent = `${Math.round(currentBattery)}%`;
        efficiency.textContent = `${currentEfficiency.toFixed(1)} mi/kWh`;
        
        // Circle progress (270deg is full circle in our design)
        const batteryAngle = (currentBattery / 100) * 270;
        circleProgress.style.transform = `rotate(${45 + batteryAngle}deg)`;
        
        // Speed, power, temp
        speed.textContent = Math.round(currentSpeed);
        power.textContent = Math.round(currentPower);
        temp.textContent = Math.round(currentTemp);
        
        // Gauges
        speedGauge.style.width = `${(currentSpeed / 150) * 100}%`;
        powerGauge.style.width = `${(currentPower / 250) * 100}%`;
        tempGauge.style.width = `${(currentTemp / 100) * 100}%`;
        
        // Change temp color if too high
        if (currentTemp > 80) {
            temp.style.color = 'var(--warning-color)';
        } else {
            temp.style.color = '#ff9500';
        }
    }
    
    // Simulate driving data changes
    function simulateDriving() {
        // Random fluctuations
        const speedChange = Math.random() * 4 - 2;
        const powerChange = Math.random() * 20 - 10;
        const tempChange = Math.random() * 0.5 - 0.25;
        
        // Apply changes with limits
        currentSpeed = Math.max(0, Math.min(currentSpeed + speedChange, 150));
        currentPower = Math.max(0, Math.min(currentPower + powerChange, 250));
        currentTemp = Math.max(20, Math.min(currentTemp + tempChange, 110));
        
        // Calculate range and battery changes based on driving
        const rangeChange = -currentSpeed * 0.01 - currentPower * 0.02;
        currentRange = Math.max(0, currentRange + rangeChange);
        
        const batteryChange = -currentSpeed * 0.005 - currentPower * 0.01;
        currentBattery = Math.max(0, currentBattery + batteryChange);
        
        // Efficiency changes slightly based on driving style
        currentEfficiency = 3.8 + Math.random() * 0.8;
        
        // Update all displays
        updateDisplays();
    }
    
    // Navigation item clicks
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Initialize
    updateDisplays();
    
    // Start simulation
    setInterval(simulateDriving, 1000);
    
    // Add some random events
    setInterval(function() {
        // Occasionally simulate acceleration
        if (Math.random() > 0.8) {
            currentSpeed = Math.min(currentSpeed + 10 + Math.random() * 20, 150);
            currentPower = Math.min(currentPower + 30 + Math.random() * 40, 250);
        }
        
        // Occasionally simulate braking
        if (Math.random() > 0.9) {
            currentSpeed = Math.max(currentSpeed - 20 - Math.random() * 30, 0);
            currentPower = Math.max(currentPower - 40 - Math.random() * 30, 0);
        }
    }, 5000);
});