// Battery Monitoring System
class BatteryMonitor {
    constructor() {
        // Initial battery state
        this.state = {
            soc: 75,        // State of Charge (0-100%)
            soh: 92,        // State of Health (0-100%)
            voltage: 402,   // Voltage in V
            current: 142,   // Current in A
            temperature: 28,// Temperature in °C
            cycles: 142,    // Charge cycles
            isCharging: false,
            isCooling: false,
            status: "OPTIMAL"
        };
        
        // History data
        this.history = {
            "24h": this.generateHistoryData(24, 1),
            "7d": this.generateHistoryData(7, 24),
            "30d": this.generateHistoryData(30, 24)
        };
        this.currentRange = "24h";
        
        // Initialize
        this.initElements();
        this.initEvents();
        this.updateDisplay();
        this.renderHistoryGraph();
        
        // Start monitoring
        this.monitorInterval = setInterval(() => this.updateBattery(), 3000);
    }
    
    initElements() {
        // Main elements
        this.elements = {
            socLevel: document.getElementById('soc-level'),
            socPercent: document.getElementById('soc-percent'),
            sohLevel: document.getElementById('soh-level'),
            sohPercent: document.getElementById('soh-percent'),
            currentValue: document.getElementById('current-value'),
            voltageValue: document.getElementById('voltage-value'),
            cycleCount: document.getElementById('cycle-count'),
            tempValue: document.getElementById('temp-value'),
            batteryStatus: document.getElementById('battery-status'),
            historyGraph: document.getElementById('history-graph'),
            maxCharge: document.getElementById('max-charge'),
            avgCharge: document.getElementById('avg-charge'),
            minCharge: document.getElementById('min-charge'),
            chargeBtn: document.getElementById('charge-btn'),
            coolBtn: document.getElementById('cool-btn'),
            rangeBtns: document.querySelectorAll('.range-btn')
        };
    }
    
    initEvents() {
        // Charge button
        this.elements.chargeBtn.addEventListener('click', () => {
            this.state.isCharging = !this.state.isCharging;
            this.updateChargeButton();
            this.playSound(this.state.isCharging ? 'chargeStart' : 'chargeStop');
        });
        
        // Cool button
        this.elements.coolBtn.addEventListener('click', () => {
            this.state.isCooling = !this.state.isCooling;
            this.updateCoolButton();
            this.playSound(this.state.isCooling ? 'coolStart' : 'coolStop');
        });
        
        // Range buttons
        this.elements.rangeBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                this.currentRange = btn.dataset.range;
                this.updateRangeButtons();
                this.renderHistoryGraph();
            });
        });
    }
    
    generateHistoryData(points, hoursPerPoint) {
        const now = new Date();
        const data = [];
        
        for (let i = 0; i < points; i++) {
            const time = new Date(now);
            time.setHours(time.getHours() - (points - i - 1) * hoursPerPoint);
            
            // Simulate different patterns based on range
            let value;
            if (hoursPerPoint === 1) { // 24h - hourly data
                if (i < 8) { // Night time - charging
                    value = 20 + Math.min(i * 10, 80) + Math.random() * 5;
                } else if (i < 18) { // Day time - discharging
                    value = 100 - Math.min((i - 8) * 8, 60) + Math.random() * 5;
                } else { // Evening - charging
                    value = 40 + Math.min((i - 18) * 15, 60) + Math.random() * 5;
                }
            } else if (hoursPerPoint === 24) { // Daily data
                if (i < 2) { // Weekend - less usage
                    value = 30 + Math.min(i * 20, 50) + Math.random() * 10;
                } else { // Weekdays - more usage
                    value = 70 - Math.min((i - 2) * 5, 40) + Math.random() * 10;
                }
            }
            
            data.push({
                time: time,
                value: Math.min(100, Math.max(0, value))
            });
        }
        
        return data;
    }
    
    updateBattery() {
        // Simulate battery changes
        if (this.state.isCharging) {
            this.state.soc = Math.min(100, this.state.soc + (1 + Math.random()));
            this.state.temperature = Math.min(45, this.state.temperature + 0.2);
            this.state.current = 150 + Math.random() * 30;
            this.state.voltage = 400 + Math.random() * 10;
        } else {
            this.state.soc = Math.max(0, this.state.soc - (0.2 + Math.random() * 0.3));
            this.state.current = 100 + Math.random() * 50;
            this.state.voltage = 390 + Math.random() * 20;
        }
        
        if (this.state.isCooling) {
            this.state.temperature = Math.max(20, this.state.temperature - 0.5);
        } else {
            // Normal temperature fluctuations
            this.state.temperature += (Math.random() * 0.4 - 0.2);
            this.state.temperature = Math.min(40, Math.max(20, this.state.temperature));
        }
        
        // SOH degrades slowly over time
        this.state.soh = Math.max(70, this.state.soh - (Math.random() * 0.01));
        
        // Add cycles when charging from low
        if (this.state.isCharging && this.state.soc < 30 && Math.random() > 0.8) {
            this.state.cycles++;
        }
        
        // Update battery status
        this.updateBatteryStatus();
        
        // Update history data
        this.updateHistoryData();
        
        // Update display
        this.updateDisplay();
    }
    
    updateBatteryStatus() {
        if (this.state.temperature > 38) {
            this.state.status = "OVERHEAT";
        } else if (this.state.soc < 10) {
            this.state.status = "CRITICAL";
        } else if (this.state.soc < 20) {
            this.state.status = "LOW";
        } else if (this.state.soh < 80) {
            this.state.status = "DEGRADED";
        } else {
            this.state.status = "OPTIMAL";
        }
    }
    
    updateHistoryData() {
        // Add current SOC to history
        const now = new Date();
        const currentData = this.history[this.currentRange];
        
        // For 24h view, add data more frequently
        if (this.currentRange === "24h") {
            if (!currentData[currentData.length - 1] || 
                now - currentData[currentData.length - 1].time > 60 * 60 * 1000) {
                currentData.shift();
                currentData.push({
                    time: now,
                    value: this.state.soc
                });
            } else {
                currentData[currentData.length - 1] = {
                    time: now,
                    value: this.state.soc
                };
            }
        }
    }
    
    updateDisplay() {
        // Update SOC
        this.elements.socLevel.style.width = `${this.state.soc}%`;
        this.elements.socPercent.textContent = `${Math.round(this.state.soc)}%`;
        
        // Update SOH
        this.elements.sohLevel.style.width = `${this.state.soh}%`;
        this.elements.sohPercent.textContent = `${Math.round(this.state.soh)}%`;
        
        // Update other values
        this.elements.currentValue.textContent = `${Math.round(this.state.current)} A`;
        this.elements.voltageValue.textContent = `${Math.round(this.state.voltage)} V`;
        this.elements.tempValue.textContent = `${Math.round(this.state.temperature)}°C`;
        this.elements.cycleCount.textContent = this.state.cycles;
        this.elements.batteryStatus.textContent = this.state.status;
        
        // Update status colors
        this.updateStatusColors();
        
        // Update history stats
        this.updateHistoryStats();
    }
    
    updateStatusColors() {
        // SOC status
        if (this.state.soc < 10) {
            this.elements.socLevel.classList.add('critical-battery');
            this.elements.socLevel.classList.remove('low-battery');
        } else if (this.state.soc < 20) {
            this.elements.socLevel.classList.add('low-battery');
            this.elements.socLevel.classList.remove('critical-battery');
        } else {
            this.elements.socLevel.classList.remove('low-battery', 'critical-battery');
        }
        
        // Charging animation
        if (this.state.isCharging) {
            this.elements.socLevel.classList.add('charging');
        } else {
            this.elements.socLevel.classList.remove('charging');
        }
        
        // Cooling animation
        if (this.state.isCooling) {
            this.elements.tempValue.classList.add('cooling');
        } else {
            this.elements.tempValue.classList.remove('cooling');
        }
        
        // Status colors
        const statusColors = {
            "OPTIMAL": "#00ffaa",
            "DEGRADED": "#ffcc00",
            "LOW": "#ff6600",
            "CRITICAL": "#ff3366",
            "OVERHEAT": "#ff0066"
        };
        
        this.elements.batteryStatus.style.color = statusColors[this.state.status];
        this.elements.batteryStatus.style.textShadow = `0 0 10px ${statusColors[this.state.status]}`;
        this.elements.batteryStatus.style.borderColor = statusColors[this.state.status];
        this.elements.batteryStatus.style.boxShadow = `0 0 15px ${statusColors[this.state.status]}33`;
    }
    
    updateChargeButton() {
        if (this.state.isCharging) {
            this.elements.chargeBtn.innerHTML = `
                <svg viewBox="0 0 24 24"><path d="M13 2.05v2.02c3.95.49 7 3.85 7 7.93 0 3.21-1.92 6-4.72 7.28l-1.5-2.67C16.2 16.26 17 14.2 17 12c0-2.74-2-5-4.5-5.3v2.45L8.2 6.4 11 3v2.01C6.08 5.57 2 9.03 2 13c0 3.31 2.69 6 6 6 1.66 0 3.14-.69 4.22-1.78l-1.41-1.41C9.85 17.1 9 15.1 9 13c0-2.22 1.28-4.14 3.15-5.03l-1.5-2.67C8.19 6.72 6 9.69 6 13c0 4.42 3.58 8 8 8 4.42 0 8-3.58 8-8 0-5.49-4.43-9.93-9.93-9.95z"/></svg>
                <span>Stop Charging</span>
            `;
            this.elements.chargeBtn.classList.add('active');
        } else {
            this.elements.chargeBtn.innerHTML = `
                <svg viewBox="0 0 24 24"><path d="M7 2v4h3v2H7v1h3v2H7v1h4v2H7v1h3v2H7v4h10v-4h-3v-2h3v-1h-3v-2h3v-1h-3v-2h4v-2h-3V8h3V7h-3V5h3V2H7z"/></svg>
                <span>Start Charging</span>
            `;
            this.elements.chargeBtn.classList.remove('active');
        }
    }
    
    updateCoolButton() {
        if (this.state.isCooling) {
            this.elements.coolBtn.innerHTML = `
                <svg viewBox="0 0 24 24"><path d="M12 2c3.86 0 7 3.14 7 7 0 2.93-1.81 5.45-4.39 6.5l.73 2.48c.15.52-.25 1.02-.78 1.02h-5.12c-.53 0-.93-.5-.78-1.02l.73-2.48C6.81 14.45 5 11.93 5 9c0-3.86 3.14-7 7-7zm0 2c-2.76 0-5 2.24-5 5 0 1.64.81 3.09 2.03 4l.97-.5.5.9c.35.62.99 1 1.73 1h.54c.74 0 1.38-.38 1.73-1l.5-.9.97.5c1.22-.91 2.03-2.36 2.03-4 0-2.76-2.24-5-5-5zm-1 2h2v5h-2V6zm0 7h2v2h-2v-2z"/></svg>
                <span>Stop Cooling</span>
            `;
            this.elements.coolBtn.classList.add('active');
        } else {
            this.elements.coolBtn.innerHTML = `
                <svg viewBox="0 0 24 24"><path d="M12 2c3.86 0 7 3.14 7 7 0 2.93-1.81 5.45-4.39 6.5l.73 2.48c.15.52-.25 1.02-.78 1.02h-5.12c-.53 0-.93-.5-.78-1.02l.73-2.48C6.81 14.45 5 11.93 5 9c0-3.86 3.14-7 7-7zm0 2c-2.76 0-5 2.24-5 5 0 1.64.81 3.09 2.03 4l.97-.5.5.9c.35.62.99 1 1.73 1h.54c.74 0 1.38-.38 1.73-1l.5-.9.97.5c1.22-.91 2.03-2.36 2.03-4 0-2.76-2.24-5-5-5z"/></svg>
                <span>Cool System</span>
            `;
            this.elements.coolBtn.classList.remove('active');
        }
    }
    
    updateRangeButtons() {
        this.elements.rangeBtns.forEach(btn => {
            if (btn.dataset.range === this.currentRange) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }
    
    updateHistoryStats() {
        const currentData = this.history[this.currentRange];
        const values = currentData.map(item => item.value);
        
        this.elements.maxCharge.textContent = `${Math.round(Math.max(...values))}%`;
        this.elements.minCharge.textContent = `${Math.round(Math.min(...values))}%`;
        this.elements.avgCharge.textContent = `${Math.round(values.reduce((a, b) => a + b, 0) / values.length)}%`;
    }
    
    renderHistoryGraph() {
        const data = this.history[this.currentRange];
        const svgWidth = 300;
        const svgHeight = 120;
        const padding = 10;
        
        // Clear previous graph
        this.elements.historyGraph.innerHTML = '';
        
        // Create SVG element
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", `0 0 ${svgWidth} ${svgHeight}`);
        svg.setAttribute("preserveAspectRatio", "none");
        
        // Create path for the graph line
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        let pathData = "";
        
        data.forEach((point, index) => {
            const x = padding + (index * (svgWidth - padding * 2) / (data.length - 1));
            const y = svgHeight - padding - (point.value / 100 * (svgHeight - padding * 2));
            
            if (index === 0) {
                pathData += `M ${x} ${y}`;
            } else {
                pathData += ` L ${x} ${y}`;
            }
        });
        
        path.setAttribute("d", pathData);
        path.setAttribute("fill", "none");
        path.setAttribute("stroke", "#00f7ff");
        path.setAttribute("stroke-width", "2");
        path.setAttribute("stroke-linecap", "round");
        path.setAttribute("stroke-linejoin", "round");
        svg.appendChild(path);
        
        // Add gradient fill under the line
        const fillPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
        fillPath.setAttribute("d", `${pathData} L ${svgWidth - padding} ${svgHeight - padding} L ${padding} ${svgHeight - padding} Z`);
        fillPath.setAttribute("fill", "url(#graphGradient)");
        fillPath.setAttribute("opacity", "0.3");
        svg.appendChild(fillPath);
        
        // Create gradient
        const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
        const gradient = document.createElementNS("http://www.w3.org/2000/svg", "linearGradient");
        gradient.setAttribute("id", "graphGradient");
        gradient.setAttribute("x1", "0%");
        gradient.setAttribute("y1", "0%");
        gradient.setAttribute("x2", "0%");
        gradient.setAttribute("y2", "100%");
        
        const stop1 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
        stop1.setAttribute("offset", "0%");
        stop1.setAttribute("stop-color", "#00f7ff");
        
        const stop2 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
        stop2.setAttribute("offset", "100%");
        stop2.setAttribute("stop-color", "#0055ff");
        
        gradient.appendChild(stop1);
        gradient.appendChild(stop2);
        defs.appendChild(gradient);
        svg.appendChild(defs);
        
        // Add current time indicator
        if (this.currentRange === "24h") {
            const nowLine = document.createElementNS("http://www.w3.org/2000/svg", "line");
            nowLine.setAttribute("x1", svgWidth - padding);
            nowLine.setAttribute("y1", padding);
            nowLine.setAttribute("x2", svgWidth - padding);
            nowLine.setAttribute("y2", svgHeight - padding);
            nowLine.setAttribute("stroke", "#00ffaa");
            nowLine.setAttribute("stroke-width", "1");
            nowLine.setAttribute("stroke-dasharray", "2,2");
            svg.appendChild(nowLine);
        }
        
        this.elements.historyGraph.appendChild(svg);
    }
    
    playSound(type) {
        const sounds = {
            chargeStart: "https://assets.mixkit.co/sfx/preview/mixkit-arcade-game-jump-coin-216.mp3",
            chargeStop: "https://assets.mixkit.co/sfx/preview/mixkit-unlock-game-notification-253.mp3",
            coolStart: "https://assets.mixkit.co/sfx/preview/mixkit-cool-interface-click-tone-2568.mp3",
            coolStop: "https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3",
            warning: "https://assets.mixkit.co/sfx/preview/mixkit-alarm-digital-clock-beep-989.mp3"
        };
        
        const sound = new Audio(sounds[type]);
        sound.volume = 0.3;
        sound.play();
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const batteryMonitor = new BatteryMonitor();
    
    // Expose to global scope for debugging
    window.batteryMonitor = batteryMonitor;
});