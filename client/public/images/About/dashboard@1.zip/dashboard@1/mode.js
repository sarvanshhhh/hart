// Mode Switching Functionality
function changeMode(mode) {
    // Remove all mode classes from body
    document.body.className = '';
    document.body.classList.add(`${mode}-mode`);
    
    // Update active button
    document.querySelectorAll('.mode-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`.mode-button[data-mode="${mode}"]`).classList.add('active');
    
    // Play mode change sound
    playModeChangeSound();
    
    // Update dashboard status
    updateDashboardStatus(mode);
    
    // Add visual effect
    animateModeChange();
}

function playModeChangeSound() {
    const sounds = {
        standard: 'https://assets.mixkit.co/sfx/preview/mixkit-arcade-game-jump-coin-216.mp3',
        performance: 'https://assets.mixkit.co/sfx/preview/mixkit-racing-countdown-919.mp3',
        security: 'https://assets.mixkit.co/sfx/preview/mixkit-security-protected-1362.mp3',
        autonomous: 'https://assets.mixkit.co/sfx/preview/mixkit-robot-positronic-2084.mp3'
    };
    
    const sound = new Audio(sounds[document.body.classList[0].split('-')[0]] || sounds.standard);
    sound.volume = 0.3;
    sound.play();
}

function updateDashboardStatus(mode) {
    const currentMode = document.getElementById('current-mode');
    const powerOutput = document.getElementById('power-output');
    const systemStatus = document.getElementById('system-status');
    
    const modes = {
        standard: {
            title: "STANDARD",
            power: "75%",
            status: "OPTIMAL",
            statusColor: "#00ffaa"
        },
        performance: {
            title: "PERFORMANCE",
            power: "100%",
            status: "MAX POWER",
            statusColor: "#ffcc00"
        },
        security: {
            title: "SECURITY",
            power: "60%",
            status: "PROTECTED",
            statusColor: "#ff3366"
        },
        autonomous: {
            title: "AUTONOMOUS",
            power: "85%",
            status: "AI ACTIVE",
            statusColor: "#00ffaa"
        }
    };
    
    currentMode.textContent = modes[mode].title;
    powerOutput.textContent = modes[mode].power;
    systemStatus.textContent = modes[mode].status;
    systemStatus.style.color = modes[mode].statusColor;
    systemStatus.style.textShadow = `0 0 8px ${modes[mode].statusColor}`;
    
    // Update title based on mode
    document.querySelector('.title').textContent = `EV ${modes[mode].title} DASHBOARD`;
}

function animateModeChange() {
    const dashboard = document.querySelector('.dashboard');
    dashboard.style.animation = "none";
    void dashboard.offsetWidth; // Trigger reflow
    dashboard.style.animation = "modeChangePulse 0.8s";
    
    // Add animation to CSS if not already present
    if (!document.getElementById('modeChangeAnimation')) {
        const style = document.createElement('style');
        style.id = 'modeChangeAnimation';
        style.textContent = `
            @keyframes modeChangePulse {
                0% { transform: scale(1); box-shadow: 0 0 30px currentColor; }
                25% { transform: scale(0.98); }
                50% { transform: scale(1.02); box-shadow: 0 0 50px currentColor; }
                100% { transform: scale(1); box-shadow: 0 0 30px currentColor; }
            }
        `;
        document.head.appendChild(style);
    }
}

// Initialize with standard mode
document.addEventListener('DOMContentLoaded', () => {
    changeMode('standard');
    
    // Add hover effects to buttons
    document.querySelectorAll('.mode-button').forEach(button => {
        button.addEventListener('mouseenter', () => {
            if (!button.classList.contains('active')) {
                button.querySelector('.mode-icon svg').style.fill = "#00ffaa";
            }
        });
        
        button.addEventListener('mouseleave', () => {
            if (!button.classList.contains('active')) {
                button.querySelector('.mode-icon svg').style.fill = "#00f7ff";
            }
        });
    });
});