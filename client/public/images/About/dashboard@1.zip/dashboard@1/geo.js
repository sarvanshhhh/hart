// Vehicle position (simulated)
let vehicle = document.getElementById("vehicle");
let locationDisplay = document.getElementById("location");
let statusDisplay = document.getElementById("status");
let obstacleDisplay = document.getElementById("obstacle");
let obstacleImg = document.getElementById("obstacle-img");

let vehiclePos = { x: 50, y: 50 }; // Initial percentage position
let fenceBoundary = { minX: 30, maxX: 70, minY: 30, maxY: 70 }; // Safe zone

// Function to move vehicle randomly
function simulateMovement() {
    vehiclePos.x = Math.floor(Math.random() * 100);
    vehiclePos.y = Math.floor(Math.random() * 100);

    vehicle.style.left = vehiclePos.x + "%";
    vehicle.style.top = vehiclePos.y + "%";

    updateStatus();
}

// Function to check if vehicle is inside geo-fence
function updateStatus() {
    let insideFence = (
        vehiclePos.x > fenceBoundary.minX &&
        vehiclePos.x < fenceBoundary.maxX &&
        vehiclePos.y > fenceBoundary.minY &&
        vehiclePos.y < fenceBoundary.maxY
    );

    locationDisplay.textContent = vehiclePos.x.toFixed(2) + ", " + vehiclePos.y.toFixed(2);

    if (insideFence) {
        statusDisplay.textContent = "✅ Inside Safe Zone";
        statusDisplay.style.color = "lime";
    } else {
        statusDisplay.textContent = "🚨 Outside Safe Zone!";
        statusDisplay.style.color = "red";
    }
}

// Function to detect obstacles randomly
function detectObstacle() {
    let obstacles = ["None", "Pedestrian", "Animal", "Pothole", "Other Vehicle"];
    let detected = obstacles[Math.floor(Math.random() * obstacles.length)];

    obstacleDisplay.textContent = detected;

    if (detected !== "None") {
        statusDisplay.textContent = "⚠️ Obstacle Detected!";
        statusDisplay.style.color = "yellow";
        obstacleImg.style.display = "block";  // Show obstacle image
    } else {
        obstacleImg.style.display = "none";  // Hide obstacle image
    }
}

// Reset vehicle position
function resetVehicle() {
    vehiclePos = { x: 50, y: 50 };
    vehicle.style.left = "50%";
    vehicle.style.top = "50%";
    
    statusDisplay.textContent = "✅ Inside Safe Zone";
    statusDisplay.style.color = "lime";
    obstacleDisplay.textContent = "None";
    locationDisplay.textContent = "50.00, 50.00";
    obstacleImg.style.display = "none";
}
