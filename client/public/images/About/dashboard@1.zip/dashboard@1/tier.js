// Function to simulate fluctuating tire pressure
function updateTirePressure() {
    const tires = [
        { id: "fl-pressure", pressure: getRandomPressure() },
        { id: "fr-pressure", pressure: getRandomPressure() },
        { id: "rl-pressure", pressure: getRandomPressure() },
        { id: "rr-pressure", pressure: getRandomPressure() }
    ];

    tires.forEach(tire => {
        const pressureElement = document.getElementById(tire.id);
        pressureElement.textContent = tire.pressure + " PSI";

        // Apply color based on pressure level
        if (tire.pressure < 28) {
            pressureElement.style.color = "red"; // Low pressure warning
            showAlert("⚠️ Low Pressure in " + tire.id.toUpperCase() + " (" + tire.pressure + " PSI)");
        } else if (tire.pressure > 36) {
            pressureElement.style.color = "yellow"; // High pressure warning
            showAlert("⚠️ High Pressure in " + tire.id.toUpperCase() + " (" + tire.pressure + " PSI)");
        } else {
            pressureElement.style.color = "green"; // Normal pressure
        }
    });
}

// Function to generate random tire pressure values (for simulation)
function getRandomPressure() {
    return (Math.random() * (38 - 25) + 25).toFixed(1); // Random between 25 and 38 PSI
}

// Function to display an alert
function showAlert(message) {
    const alertBox = document.getElementById("alert-box");
    alertBox.textContent = message;
    alertBox.style.display = "block";

    // Hide the alert after 3 seconds
    setTimeout(() => {
        alertBox.style.display = "none";
    }, 3000);
}

// Update tire pressure every 2 seconds
setInterval(updateTirePressure, 2000);
// Function to normalize all tire pressures to 32 PSI
function normalizePressure() {
    const defaultPressure = 32;
    const tires = ["fl-pressure", "fr-pressure", "rl-pressure", "rr-pressure"];

    tires.forEach(tire => {
        const pressureElement = document.getElementById(tire);
        pressureElement.textContent = defaultPressure + " PSI";
        pressureElement.style.color = "green"; // Normal pressure color
    });

    showAlert("✅ Tire pressures normalized to 32 PSI.");
}
