// motor.js
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const motorStatus = document.getElementById('motor-status');
    const rpmValue = document.getElementById('rpm-value');
    const powerValue = document.getElementById('power-value');
    const tempValue = document.getElementById('temp-value');
    const efficiencyValue = document.getElementById('efficiency-value');
    const rpmGauge = document.getElementById('rpm-gauge');
    const powerGauge = document.getElementById('power-gauge');
    const tempGauge = document.getElementById('temp-gauge');
    const efficiencyGauge = document.getElementById('efficiency-gauge');
    const historyGraph = document.getElementById('history-graph');
    const peakPower = document.getElementById('peak-power');
    const avgTemp = document.getElementById('avg-temp');
    const maxRpm = document.getElementById('max-rpm');
    const regenBtn = document.getElementById('regen-btn');
    const powerBtn = document.getElementById('power-btn');
    const regenLevel = document.getElementById('regen-level');
    const powerMode = document.getElementById('power-mode');
    const rangeButtons = document.querySelectorAll('.range-btn');

    // Initial values
    let currentRpm = 4200;
    let currentPower = 215;
    let currentTemp = 68;
    let currentEfficiency = 94;
    let currentRegenLevel = 2;
    let currentPowerMode = 'Sport';
    const powerModes = ['Eco', 'Comfort', 'Sport', 'Track'];
    const statusMessages = ['OPTIMAL', 'WARNING', 'CRITICAL'];

    // Update gauges function
    function updateGauges() {
        // RPM gauge (max 10000 RPM)
        const rpmPercent = Math.min(currentRpm / 10000 * 100, 100);
        rpmGauge.style.width = `${rpmPercent}%`;
        
        // Power gauge (max 300 kW)
        const powerPercent = Math.min(currentPower / 300 * 100, 100);
        powerGauge.style.width = `${powerPercent}%`;
        
        // Temp gauge (warning at 80°C, critical at 100°C)
        const tempPercent = Math.min(currentTemp / 100 * 100, 100);
        tempGauge.style.width = `${tempPercent}%`;
        
        // Efficiency gauge (always 0-100%)
        efficiencyGauge.style.width = `${currentEfficiency}%`;
        
        // Update status based on temperature
        if (currentTemp >= 100) {
            motorStatus.textContent = 'CRITICAL';
            motorStatus.style.color = '#ff3a30';
            tempGauge.style.backgroundColor = '#ff3a30';
        } else if (currentTemp >= 80) {
            motorStatus.textContent = 'WARNING';
            motorStatus.style.color = '#ff9500';
            tempGauge.style.backgroundColor = '#ff9500';
        } else {
            motorStatus.textContent = 'OPTIMAL';
            motorStatus.style.color = '#34c759';
            tempGauge.style.backgroundColor = '#34c759';
        }
    }

    // Simulate random data changes
    function simulateData() {
        // Random fluctuations
        const rpmChange = Math.random() * 400 - 200;
        const powerChange = Math.random() * 30 - 15;
        const tempChange = Math.random() * 2 - 1;
        const efficiencyChange = Math.random() * 1 - 0.5;
        
        // Apply changes with limits
        currentRpm = Math.max(0, Math.min(currentRpm + rpmChange, 10000));
        currentPower = Math.max(0, Math.min(currentPower + powerChange, 300));
        currentTemp = Math.max(20, Math.min(currentTemp + tempChange, 110));
        currentEfficiency = Math.max(80, Math.min(currentEfficiency + efficiencyChange, 98));
        
        // Update display values
        rpmValue.textContent = Math.round(currentRpm).toLocaleString();
        powerValue.textContent = Math.round(currentPower);
        tempValue.textContent = Math.round(currentTemp);
        efficiencyValue.textContent = Math.round(currentEfficiency);
        
        // Update gauges
        updateGauges();
        
        // Update history stats (simplified)
        peakPower.textContent = `${Math.round(currentPower * 1.3)} kW`;
        avgTemp.textContent = `${Math.round(currentTemp * 0.9)}°C`;
        maxRpm.textContent = Math.round(currentRpm * 1.8).toLocaleString();
    }

    // Create a simple history graph
    function createHistoryGraph(range = '15m') {
        // Clear previous graph
        historyGraph.innerHTML = '';
        
        // Create canvas for the graph
        const canvas = document.createElement('canvas');
        canvas.width = historyGraph.offsetWidth;
        canvas.height = historyGraph.offsetHeight;
        historyGraph.appendChild(canvas);
        
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        
        // Draw grid lines
        ctx.strokeStyle = '#2a2a2a';
        ctx.lineWidth = 1;
        
        // Horizontal lines
        for (let i = 0; i <= 5; i++) {
            const y = height - (i * height / 5);
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(width, y);
            ctx.stroke();
        }
        
        // Vertical lines (time markers)
        const timeMarkers = range === '15m' ? 5 : range === '1h' ? 6 : 12;
        for (let i = 0; i <= timeMarkers; i++) {
            const x = i * width / timeMarkers;
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, height);
            ctx.stroke();
        }
        
        // Generate random data points based on range
        const dataPoints = range === '15m' ? 30 : range === '1h' ? 60 : 120;
        const data = [];
        
        for (let i = 0; i < dataPoints; i++) {
            const baseValue = currentPower * (0.7 + Math.random() * 0.6);
            data.push(baseValue);
        }
        
        // Draw power line
        ctx.strokeStyle = '#34c759';
        ctx.lineWidth = 2;
        ctx.beginPath();
        
        for (let i = 0; i < dataPoints; i++) {
            const x = i * width / (dataPoints - 1);
            const y = height - (data[i] / 300 * height);
            
            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        
        ctx.stroke();
    }

    // Event listeners
    regenBtn.addEventListener('click', function() {
        currentRegenLevel = currentRegenLevel < 3 ? currentRegenLevel + 1 : 0;
        regenLevel.textContent = currentRegenLevel;
        
        // Adjust efficiency based on regen level
        currentEfficiency = 92 + currentRegenLevel * 2;
        efficiencyValue.textContent = Math.round(currentEfficiency);
        efficiencyGauge.style.width = `${currentEfficiency}%`;
    });

    powerBtn.addEventListener('click', function() {
        const currentIndex = powerModes.indexOf(currentPowerMode);
        const nextIndex = (currentIndex + 1) % powerModes.length;
        currentPowerMode = powerModes[nextIndex];
        powerMode.textContent = currentPowerMode;
        
        // Adjust power characteristics based on mode
        switch(currentPowerMode) {
            case 'Eco':
                currentPower = Math.min(currentPower, 150);
                break;
            case 'Comfort':
                currentPower = Math.min(currentPower, 200);
                break;
            case 'Sport':
                currentPower = Math.min(currentPower, 250);
                break;
            case 'Track':
                currentPower = Math.min(currentPower, 300);
                break;
        }
        
        powerValue.textContent = Math.round(currentPower);
        updateGauges();
    });

    rangeButtons.forEach(button => {
        button.addEventListener('click', function() {
            rangeButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            createHistoryGraph(this.dataset.range);
        });
    });

    // Initialize
    updateGauges();
    createHistoryGraph('15m');
    
    // Set up data simulation
    setInterval(simulateData, 2000);
    
    // Handle window resize
    window.addEventListener('resize', function() {
        createHistoryGraph(document.querySelector('.range-btn.active').dataset.range);
    });
});