// Quick Access Menu Toggle
function toggleQuickAccess() {
    let quickAccess = document.getElementById("quickAccessMenu");
    quickAccess.classList.toggle("active"); // Toggle visibility
}

// Function to open Google Maps with URL
function openMap(url) {
    window.open(url, '_blank');
}

// Function to search nearby locations (Geolocation + Google Maps)
function searchNearby(placeType) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const mapUrl = `https://www.google.com/maps/search/${placeType}/@${latitude},${longitude},15z`;
                window.open(mapUrl, '_blank');
            },
            (error) => {
                console.warn("Geolocation error:", error);
                alert("Could not fetch location. Opening Google Maps search.");
                window.open(`https://www.google.com/maps/search/${placeType}`, "_blank");
            }
        );
    } else {
        alert("Geolocation is not supported. Opening Google Maps search.");
        window.open(`https://www.google.com/maps/search/${placeType}`, "_blank");
    }
}

// Add click event listeners for all icons
document.addEventListener("DOMContentLoaded", function () {
    const icons = document.querySelectorAll(".icon");
    
    icons.forEach(icon => {
        icon.addEventListener("click", function () {
            const placeType = this.dataset.place; // Fetch place type from dataset
            if (placeType) {
                searchNearby(placeType);
            }
        });
    });
});





//bottamnav bar wala function  
// Car Settings Function
function openCarSettings() {
    alert("Opening Car Settings...");
    // Yahan aap EV settings ka page ya modal open kar sakte hain
}
// Fan Control Function
function toggleFan() {
    alert("Fan toggled!");
    // Yahan fan ka state ON/OFF toggle karne ka logic daal sakte hain
}
// Music Player Function
function openMusicPlayer() {
    alert("Opening Music Player...");
    // Yahan aap music player ka modal ya new page khol sakte hain
}
// Volume Adjustment Function
function adjustVolume() {
    alert("Adjusting Volume...");
    // Yahan aap volume ko increase/decrease ka option add kar sakte hain
}
// Mobile App Function
function openPhoneApp() {
    alert("Opening Phone App...");
    // Yahan aap phone dialer ya contacts ko access kar sakte hain
}
// Voice Search Function
function startVoiceSearch() {
    alert("Listening for Voice Command...");
    // Yahan aap Web Speech API ya AI Assistant integrate kar sakte hain
}
// Search Box Enter Key Functionality
document.getElementById("searchBox").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        alert("Searching for: " + this.value);
        // Yahan actual search logic implement kar sakte hain
    }
});


