/* script.js */
function toggleLock() {
    let lockIcon = document.getElementById("lock-icon");
    let statusText = document.getElementById("status-text");
    if (lockIcon.classList.contains("locked")) {
        lockIcon.classList.remove("locked");
        lockIcon.classList.add("unlocked");
        lockIcon.innerHTML = "&#128275;";
        statusText.innerText = "Unlocked";
    } else {
        lockIcon.classList.remove("unlocked");
        lockIcon.classList.add("locked");
        lockIcon.innerHTML = "&#128274;";
        statusText.innerText = "Locked";
    }
}
function toggleAlarm() {
    alert("Alarm toggled!");
}
function toggleLights() {
    alert("Lights toggled!");
}
function toggleEngine() {
    alert("Engine Start/Stop toggled!");
}
function updateSecurity() {
    let intrusionStatus = ["No Threat Detected", "Suspicious Activity", "Intrusion Detected!"];
    let randomIntrusion = intrusionStatus[Math.floor(Math.random() * intrusionStatus.length)];
    document.getElementById("intrusion-status").innerText = randomIntrusion;
}
setInterval(updateSecurity, 4000);
